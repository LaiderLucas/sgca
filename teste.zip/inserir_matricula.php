<?php
// inicia a session
session_start();
date_default_timezone_set('America/Cuiaba');
$dtmatricula = date('Y-m-d');
$controle = $_POST['controle'];
$ndiario = $_POST['ndiario'];

include('config.php');

$PDO = db_connect();
die;



for ($i = 1; $i <= $controle; $i++) {
$m = "matricula".$i;

	
$matricula = $_POST[$m];

	

	$sql="INSERT INTO `$banco`.`$tabela_matricula` (`sga_matricula_Aluno`, `sga_matricula_Diario`, `sga_matricula_dtmatricula`) VALUES 
	(:ndiario, :matricula, :dtmatricula);

	";
	
	$stmt = $PDO->prepare($sql);
	$stmt->BindParam(':ndiario', $ndiario);
	$stmt->BindParam(':matricula', $matricula);
	$stmt->BindParam(':dtmatricula',$dtmatricula);
	if ($stmt->execute()){
		$_SESSION['sucesso'] = 1;
	}else {
		$_SESSION['sucesso'] = 0;
		$_SESSION['aviso'] = "ERRO AO CADASTRAR ALUNOS!";
		print_r($stmt);	
	die;
	}
}






// volta para a pagina de cadastro do usuário
header('Location:add_alunos.php');
?>
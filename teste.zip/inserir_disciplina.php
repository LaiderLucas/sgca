<?php
// inicia a session
session_start();
$nomeDisciplina = $_POST['nomeDisciplina'];
$nivel = $_POST['nivel'];


include('config.php');

$PDO = db_connect();


$sql="INSERT INTO `$banco`.`$tabela_disciplina` (`sga_disciplina_Nome`, `sga_disciplina_Nivel`) VALUES (:nomeDisciplina, :nivel);
";

$stmt = $PDO->prepare($sql);
$stmt->BindParam(':nomeDisciplina', $nomeDisciplina);
$stmt->BindParam(':nivel',$nivel);



if ($stmt->execute()){
	$_SESSION['sucesso'] = 1;
}else {
	$_SESSION['sucesso'] = 0;
	$_SESSION['aviso'] = "ERRO AO CADASTRAR CURSO!";
	print_r($stmt);	
die;
}


// volta para a pagina de cadastro do usuário
header('Location:add_disciplinas.php');
?>
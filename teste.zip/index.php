<!DOCTYPE html>
<html lang="pt-br">
<?php
include('config.php');
?>    
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>SGCA - SISTEMA DE GESTÃO E CONTROLE DE AULAS</title>

        <!-- ================= Favicon ================== -->
        <!-- Standard -->
        <link rel="shortcut icon" href="">
        <!-- Retina iPad Touch Icon-->
        <link rel="apple-touch-icon" sizes="144x144" href="">
        <!-- Retina iPhone Touch Icon-->
        <link rel="apple-touch-icon" sizes="114x114" href="">
        <!-- Standard iPad Touch Icon-->
        <link rel="apple-touch-icon" sizes="72x72" href="">
        <!-- Standard iPhone Touch Icon-->
        <link rel="apple-touch-icon" sizes="57x57" href="">

        <!-- Styles -->
        <link href="assets/css/lib/weather-icons.css" rel="stylesheet" />
        <link href="assets/css/lib/owl.carousel.min.css" rel="stylesheet" />
        <link href="assets/css/lib/owl.theme.default.min.css" rel="stylesheet" />
        <link href="assets/css/lib/font-awesome.min.css" rel="stylesheet">
        <link href="assets/css/lib/themify-icons.css" rel="stylesheet">
        <link href="assets/css/lib/menubar/sidebar.css" rel="stylesheet">
        <link href="assets/css/lib/bootstrap.min.css" rel="stylesheet">

        <link href="assets/css/lib/helper.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
    </head>

    <body>
<?php
require_once('menu.php');

?>
        <!-- /# sidebar -->


        <div class="content-wrap">
            <div class="main">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-8 p-r-0 title-margin-right">
                            <div class="page-header">
                                <div class="page-title">
                                    <h1>Olá, <span>Administrador</span></h1>
                                </div>
                            </div>
                        </div>
                        <!-- /# column -->
                        <div class="col-lg-4 p-l-0 title-margin-left">
                            <div class="page-header">
                                <div class="page-title">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                                        <li class="breadcrumb-item active">Página Inicial</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                        <!-- /# column -->
                    </div>
                    
                       <div class="row">
                            <div class="col-lg-6">
                                <div class="card">
                                    <div class="card-title">
                                        <h4>Tarefas ** Implantação Futura **</h4>
                                    </div>
                                    <div class="todo-list">
                                        <div class="tdl-holder">
                                            <div class="tdl-content">
                                                <ul>
                                                    <li>
                                                        <label>
                                                        <input type="checkbox"><i></i><span>Provas das turmas do 3º ano</span>
                                                        <a href='#' class="ti-close"></a>
                                                    </label>
                                                    </li>
                                                    <li>
                                                        <label>
                                                        <input type="checkbox" checked><i></i><span>Lançamento das notas do 3º Bimestre no Q-Acadêmico</span>
                                                        <a href='#' class="ti-close"></a>
                                                    </label>
                                                    </li>
                                                    
                                                </ul>
                                            </div>
                                            <input type="text" class="tdl-new form-control" placeholder="Escreva a nova tarefa aqui e pressione 'Enter'">
                                        </div>
                                    </div>
                                </div>
                            </div>
                           
                            <!-- /# column -->
                        <div class="col-lg-6">
                           <div class="card">
                               <div class="card-title">
                                        <h4>Trocas e Reposições de Aulas </h4>
                                </div>
                                    <div class="recent-comment">
                                    
                                            <?php
                                            
                                            $PDO = db_connect();
                                            $query0 = "SELECT sga_trocas.sga_trocas_IDTroca as ID, sga_turma.sga_turma_SerieAno AS ano, sga_turma.sga_turma_ano_semestre AS ano_semestre, sga_curso.sga_curso_Nome AS nomeCurso, 
                                            sga_turma.sga_turma_Turno AS Turno,   
                                            sga_trocas.sga_trocas_DtReposicao as DtReposicao, sga_trocas.sga_trocas_HrReposicao_I as HrReposicao_I, sga_trocas.sga_trocas_HrReposicao_T as HrReposicao_T, sga_trocas.sga_trocas_Justificativa as Justificativa, 
                                            sga_trocas.sga_trocas_professor as professor
                                            FROM sga_trocas 
                                            inner join sga_aulas on sga_aulas.sga_aulas_IDTroca = sga_trocas.sga_trocas_IDTroca 
                                            INNER JOIN sga_diario ON sga_diario.sga_diario_ID = sga_aulas.sga_aulas_NDiario 
                                            INNER JOIN sga_turma ON sga_turma_ID = sga_diario.sga_diario_Turma 
                                            INNER JOIN sga_curso ON sga_curso.sga_curso_ID = sga_turma.sga_turma_Curso
                                            where sga_trocas.sga_trocas_DtReposicao >= CURRENT_DATE() order by DtReposicao";
                                            $stmt0 = $PDO->prepare($query0);
                                            $stmt0->execute();
                                            
                                            
                                           
                                            while ($row0 = $stmt0->fetch(PDO::FETCH_ASSOC))
                                            
                                            {
                                                $dtr = implode('/', array_reverse(explode('-', $row0['DtReposicao'])));
                                                if($dtr == date('d/m/Y')){
                                                    $repHoje = "Reposição Hoje";
                                                    $btn_cor = "danger";
                                                }else{
                                                    $repHoje = "Confirmada";
                                                    $btn_cor = "success";  
                                                };
                                            
                                            echo'
                                            <div class="media">
                                            <div class="media-body">
                                                <h4 class="media-heading"> '.$row0['ano'].' º '.$row0['ano_semestre'].' - '.$row0['nomeCurso'].' - '.$row0['Turno'].'</h4>
                                                <p><b>Início às:  '.$row0['HrReposicao_I'].' - Término às: '.$row0['HrReposicao_T'].' </b></p>
                                                <p>OBS: '.$row0['Justificativa'].' </p>
                                            <div class="comment-action">
                                                    <div class="badge badge-'.$btn_cor.'">'.$repHoje.'</div>
                                                    <span class="m-l-10">
													<a href="#"><i class="ti-check color-success"></i></a>
													<a href="#"><i class="ti-close color-danger"></i></a>
													<a href="#"><i class="fa fa-reply color-primary"></i></a>
												    </span>
                                            </div>
                                                <p class="comment-date">'.$dtr.'</p>
                                         </div>
                                        </div>
                                            ';
                                            }
                                            ?>
                    </div>
                    </div>
                                <!-- /# card -->
                            </div>
                       
<div class="row">
                           
                            <!-- Tabela -->
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-title">
                                        <h4>Aulas </h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Nº Diario</th>
                                                        <th>Turma</th>
                                                        <th>Disciplina</th>
                                                        <th>Data</th>
                                                        <th>Horario</th>
                                                        <th>Nº Aulas</th>
                                                        <th>Status/Ação</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <?php
$ID = 0;
$PDO = db_connect();

$sql = "SELECT $tabela_aulas.sga_aulas_qtdAulas AS qtdaulas, 
$tabela_aulas.sga_aulas_Data AS dataAula, $tabela_aulas.sga_aulas_HoraI AS horaI, $tabela_aulas.sga_aulas_HoraT AS horaT, 
$tabela_aulas.sga_aulas_Obs AS obs, $tabela_aulas.sga_aulas_Conteudo AS conteudo, $tabela_aulas.sga_aulas_IDTroca AS Troca,
$tabela_diario.sga_diario_Disciplina AS disciplina, $tabela_diario.sga_diario_Turma AS turma, $tabela_diario.sga_diario_Numero AS diario,
$tabela_turma.sga_turma_Turno AS Turno, $tabela_turma.sga_turma_SerieAno AS ano,$tabela_turma.sga_turma_ano_semestre AS ano_semestre, $tabela_turma.sga_turma_AnoInicio AS anoInicio,
$tabela_curso.sga_curso_Nome AS nomeCurso,
$tabela_disciplina.sga_disciplina_Nome AS nomeDisciplina
FROM $tabela_aulas
INNER JOIN $tabela_diario ON $tabela_diario.sga_diario_ID = $tabela_aulas.sga_aulas_NDiario
INNER JOIN $tabela_turma ON sga_turma_ID = $tabela_diario.sga_diario_Turma
INNER JOIN $tabela_curso ON $tabela_curso.sga_curso_ID = $tabela_turma.sga_turma_Curso
INNER JOIN $tabela_disciplina ON $tabela_disciplina.sga_disciplina_ID = $tabela_diario.sga_diario_Disciplina
ORDER BY dataAula DESC;" ;
$stmt = $PDO->prepare($sql);
$stmt->execute();

while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
 {

$data = date('d/m/Y', strtotime($row['dataAula'])); // converte a data para o formato brasileiro DD/MM/AAAA

$ID++;

if (($row['Troca'] == null) or ($row['Troca'] == "")){

    $btn = "success";
    $tipo = "N";
}else{
    $btn = "warning";
    $tipo = "T";
}
                                              echo"  <tbody>
                                                    <tr>
                                                        <td>".$ID."</td>
                                                        <td>".$row['diario']."</td>
                                                        <td>".$row['ano']."º - ".$row['ano_semestre']." - ".$row['nomeCurso']." - ".$row['Turno']."</td>
                                                        <td>".$row['nomeDisciplina']."</td>
                                                        <td>".$data."</td>
                                                        <td>".$row['horaI']." às ".$row['horaT']."</td>
                                                        <td>".$row['qtdaulas']."</td>
                                                        <td><span class='btn btn-".$btn." btn-rounded m-b-10 m-l-5'>".$tipo."</span>
                                                        <a href='#' data-toggle='modal' data-target='#add-category-".$ID."' class='btn btn-info btn-outline btn-rounded m-b-10 m-l-5'>
                                                        <i class='fa fa-plus'></i> Info </a></td>
                                                    </tr>";
 }    
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
<?php
                                                $ID = 0;
                                                $PDO = db_connect();
                                                
                                                $sql = "SELECT $tabela_aulas.sga_aulas_Data AS dataAula, $tabela_aulas.sga_aulas_IDTroca AS troca, $tabela_aulas.sga_aulas_dtLanacamento AS dtlancamento, $tabela_aulas.sga_aulas_dtEdicao AS dt_edicao,
                                                $tabela_aulas.sga_aulas_Obs AS obs, $tabela_aulas.sga_aulas_Conteudo AS conteudo, $tabela_aulas.sga_aulas_planoAula AS planoAula,
                                                $tabela_aulas.sga_aulas_material_aula AS material_aula, $tabela_aulas.sga_aulas_atividade AS atividades
                                                FROM $tabela_aulas
                                                INNER JOIN $tabela_diario ON $tabela_diario.sga_diario_ID = $tabela_aulas.sga_aulas_NDiario
                                                INNER JOIN $tabela_turma ON sga_turma_ID = $tabela_diario.sga_diario_Turma
                                                INNER JOIN $tabela_curso ON $tabela_curso.sga_curso_ID = $tabela_turma.sga_turma_Curso
                                                INNER JOIN $tabela_disciplina ON $tabela_disciplina.sga_disciplina_ID = $tabela_diario.sga_diario_Disciplina
                                                ORDER BY dataAula DESC;;" ;
                                                $stmt = $PDO->prepare($sql);
                                                $stmt->execute();
                                                
                                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
                                                 {
                                                
                                                $data = date('d/m/Y', strtotime($row['dataAula'])); // converte a data para o formato brasileiro DD/MM/AAAA
                                                
                                                $datalanc = date('d/m/Y', strtotime($row['dtlancamento']));

                                                $ID++;

                                                if ($row['planoAula'] == ''){
                                                    $semlinkp = "Sem Link do Plano de Aulas";
                                                }else{
                                                    $semlinkp = "Click Para Visualizar";
                                                }
                                                if ($row['material_aula'] == ''){
                                                    $semlinkm = "Sem Link do Material da Aula";
                                                }else{
                                                    $semlinkm = "Click Para Visualizar";
                                                }
                                                if ($row['atividades'] == ''){
                                                    $semlinka = "Sem Link da Atividade";
                                                }else{
                                                    $semlinka = "Click Para Visualizar";
                                                }
echo"
<div class='modal fade none-border' id='add-category-".$ID."'>
    <div class='modal-dialog'>
        <div class='modal-content'>
                        <div class='modal-header'>
                              <button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
                              <h4 class='modal-title'><strong>Informações Adicionais</strong></h4>
                        </div>
            <div class='modal-body'>
                            
                        <div class='row'>
                        
                      

                            <div class='col-md-6'>
                                  <h5>Data de Lançamento: </h5>
                                    <label class='control-label'>".$datalanc."</label>

                            </div>
                        
                        <div class='col-md-6'>
                                  <h5>Conteúdo: </h5>
                                    <label class='control-label'>".$row['conteudo']."</label>
                                    
                         </div>
                            <div class='col-md-6'>
                                  <h5>Observações: </h5>
                                    <label class='control-label'>".$row['obs']."</label>

                            </div>

                            <div class='col-md-6'>
                                  <h5>Plano de Aula: </h5>
                                    
                                  <label class='control-label'><a href='".$row['planoAula']."'> ".$semlinkp." </a></label>

                            </div>

                            <div class='col-md-6'>
                                  <h5>Material Da Aula: </h5>
                                    <label class='control-label'><a href='".$row['material_aula']."'> ".$semlinkm." </a></label>

                            </div>

                            <div class='col-md-6'>
                                  <h5>Atividades: </h5>
                                    <label class='control-label'><a href='".$row['atividades']."'> ".$semlinka." </a></label>

                            </div>
                            ";
if ($row['troca'] > 0){
$t = $row['troca'];                         
$query1 = "SELECT sga_trocas_DtReposicao, sga_trocas_HrReposicao_I, sga_trocas_HrReposicao_T, sga_trocas_professor FROM $banco.sga_trocas where sga_trocas_IDTroca = $t;";
$stmt1 = $PDO->prepare($query1);
$stmt1->execute();
$row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
$dtr = implode('/', array_reverse(explode('-', $row1['sga_trocas_DtReposicao'])));


    echo"  <div class='col-md-6'>
                                  <h5>Dados da Troca: </h5>
                                    <label class='control-label'>Aula Trocada com <b>".$row1['sga_trocas_professor']."</b> - Hora e Data que irá repor as aulas <b>".$dtr."</b> - das<b> ".$row1['sga_trocas_HrReposicao_I']."</b> às <b>".$row1['sga_trocas_HrReposicao_T']."</b></label>

                            </div>";
} else {
    echo"  <div class='col-md-6'>
    <h5>Dados da Troca: </h5>
      <label class='control-label'>Sem Dados de Trocas!</label>

</div>";   
}



  echo"
                            </div>

                             
            </div>
                            <div class='modal-footer'>
                              <button type='button' class='btn btn-default waves-effect' data-dismiss='modal'>Close</button>
                              
                            </div>
        </div>
    </div>
</div>";


                                                 }
            ?>




                        <div class="row">
                            <div class="col-lg-12">
                                <div class="footer">
                                    <p><?php echo date('Y');?> - © - Todos Direitos Reservados </p>
                                </div>
                            </div>
                        </div>








                   
                </div>
            </div>
        </div>
        
        

        <!-- jquery vendor -->
        <script src="assets/js/lib/jquery.min.js"></script>
        <script src="assets/js/lib/jquery.nanoscroller.min.js"></script>
        <!-- nano scroller -->
        <script src="assets/js/lib/menubar/sidebar.js"></script>
        <script src="assets/js/lib/preloader/pace.min.js"></script>
        <!-- sidebar -->
        <script src="assets/js/lib/bootstrap.min.js"></script>

        <!-- bootstrap -->

        <script src="assets/js/lib/circle-progress/circle-progress.min.js"></script>
        <script src="assets/js/lib/circle-progress/circle-progress-init.js"></script>

        <script src="assets/js/lib/morris-chart/raphael-min.js"></script>
        <script src="assets/js/lib/morris-chart/morris.js"></script>
        <script src="assets/js/lib/morris-chart/morris-init.js"></script>

        

        <script src="assets/js/lib/weather/jquery.simpleWeather.min.js"></script>
        <script src="assets/js/lib/weather/weather-init.js"></script>
        <script src="assets/js/lib/owl-carousel/owl.carousel.min.js"></script>
        <script src="assets/js/lib/owl-carousel/owl.carousel-init.js"></script>
        <script src="assets/js/scripts.js"></script>
        <!-- scripit init-->

    </body>

</html>

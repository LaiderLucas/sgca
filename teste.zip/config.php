<?php

//config geral

// constantes com as credenciais de acesso ao banco MySQL

define('DB_HOST', '127.0.0.1');

define('DB_USER', 'root');

define('DB_PASS', '');

define('DB_NAME', 'sga');

// Definindo banco e tabelas
$base_teste = true;
$banco = "sga";
$tabela_aulas = "sga_aulas";
$tabela_aluno = "sga_aluno";
$tabela_curso = "sga_curso";
$tabela_diario = "sga_diario";
$tabela_disciplina = "sga_disciplina";
$tabela_horarioaula = "sga_horarioaula";
$tabela_matricula = "sga_matricula";
$tabela_presencas = "sga_presencas";
$tabela_trocas = "sga_trocas";
$tabela_turma = "sga_turma";





// Classe de Conexão com o banco de dados

function db_connect()

{
	
    $PDO = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8', DB_USER, DB_PASS);


    return $PDO;

}

//====================================================================================================

if ($base_teste == true) {

    echo "
    <h2 style='color:red; text-align: center;'>BASE DE DADOS TESTE</h2> 
    ";
}

?>

 